# Vortex Dwyte Voting System

Don't forget to run **npm install** after cloning.

**Documentation:**
https://documenter.getpostman.com/view/5824950/RzfcMBRA

**Setup Guide**
https://youtu.be/5jn_CIeIfgY
